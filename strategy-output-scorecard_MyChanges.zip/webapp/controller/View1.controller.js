sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"ZSSCOREDEMO/model/formatter",
	 "sap/m/MessageToast"
], function(Controller, JSONModel, formatter, MessageToast) {
	"use strict";

	return Controller.extend("ZSSCOREDEMO.controller.View1", {
		
		formatter: formatter,
		
		 onInit : function () {
            // var oModel = new JSONModel(jQuery.sap.getModulePath("ZSSCOREDEMO.model","/values.json"));
            // this.getView().setModel(oModel);
            var that = this;
            this.key = null;
            var oApp = sap.ui.core.Component.getOwnerIdFor(this.getView()).split("-")[2];
            
            that.getOwnerComponent().getModel("mainService").read("/SectionScorecardSet", {
                // filters: oFilters,
                success: function(OData) {
                var jsonModelForm = new sap.ui.model.json.JSONModel();
                // that.byId("TreeTableBasic").setModel(jsonModelForm);
                that.byId("TreeTableBasic").setModel(jsonModelForm, "table"); 
                jsonModelForm.setData(OData.results);
   

                // })}
                }});
        },

        onCollapseAll: function () {
            var oTreeTable = this.getView().byId("TreeTableBasic");
            oTreeTable.collapseAll();
        },

        onExpandFirstLevel: function () {
            var oTreeTable = this.getView().byId("TreeTableBasic");
            oTreeTable.expandToLevel(1);
        },
        
         onPressView : function () {
        	MessageToast.show("Move to Strategy Definition");
      }

	});
});