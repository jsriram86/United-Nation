sap.ui.define([], function() {
	"use strict";
	return {
		stateColor: function (state) {
			if (state === "bottom") {
				return "red";
			}
			
			if (state === "right") {
				return "orange";
			}
			
			return "green";
			
		}
	};
});