sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"ZSSCOREDEMO/model/models"
], function(UIComponent, Device, models) {
	"use strict";

	return UIComponent.extend("ZSSCOREDEMO.Component", {

		metadata: {
			manifest: "json",
		 dependencies : {
             libs : ["sap.m", "sap.ui.layout", "sap.ui.unified"]
                }
		},
		

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function() {
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);
			// initialize the error handler with the component
            // this._oErrorHandler = new ErrorHandler(this);
			// set the device model
			this.setModel(models.createDeviceModel(), "device");
		}
	});
});