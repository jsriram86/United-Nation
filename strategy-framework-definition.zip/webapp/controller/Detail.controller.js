/*global location */
sap.ui.define([
	"zui5_fwdef/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"zui5_fwdef/model/formatter",
	"sap/m/Dialog",
	"sap/m/Input",
	"sap/m/Checkbox",
	"sap/m/Button"
], function(BaseController, JSONModel, formatter, Dialog, Input, Checkbox, Button) {
	"use strict";

	return BaseController.extend("zui5_fwdef.controller.Detail", {

		formatter: formatter,
		sObjectId: null,
		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		onInit: function() {
			// Model used to manipulate control states. The chosen values make sure,
			// detail page is busy indication immediately so there is no break in
			// between the busy indication for loading the view's meta data
			var oViewModel = new JSONModel({
				busy: false,
				delay: 0,
				periods: [],
				selectedPeriod: {},
				createForm: {
					text: null
				},
				periodForm: {
					Text: null,
					Status: null
				},
				statuses: [
					{
						status: "OPEN",
						name: "Open"
					}, {
						status: "CLOSED",
						name: "Closed"
					}
				]
			});

			this.getRouter().getRoute("object").attachPatternMatched(this._onObjectMatched, this);

			this.setModel(oViewModel, "detailView");

			this.getOwnerComponent().getModel().metadataLoaded().then(this._onMetadataLoaded.bind(this));
		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		onDeleteFrameworkPress: function() {
			var dialog;
			var that = this;
			var framework = this.getView().getBindingContext().getObject();

			dialog = this.confirmDialog("Are you sure you want to delete this element?", function() {

				var entitySet = "/MASTER_ELEMENTSSet(" + framework.Id + ")";
				that.getRootModel().remove(entitySet, {
					success: function(oData, response) {
						that.showMessageToast("Element deleted");
						dialog.close();
						that.treeCallbackRefresh();
					},
					error: function(oError) {
						that.showErrorBox("Deletion Failed");
						dialog.close();
					}
				});
			});
		},
		
		onSubmitPeriodForm: function()
		{
			var periodForm = this.getModel("detailView").getProperty("/periodForm");
			
			if (periodForm.Id) {
				return this.onSubmitEditPeriod();
			}
			
			return this.onSubmitCreatePeriod();
		},

		onSubmitEditFramework: function() {
			var frameworkText = sap.ui.getCore().byId("editFrameworkText").getValue();
			
			var instantiationEnabled = sap.ui.getCore().byId("editInstantiationEnabled").getSelected();
			var userCreatable = sap.ui.getCore().byId("editUserCreatable").getSelected();
			var isProject = sap.ui.getCore().byId("editIsProject").getSelected();
			var sortf = sap.ui.getCore().byId("sectionSortf").getValue();
			var faGroupId = sap.ui.getCore().byId("faGroupId").getSelectedKey();

			var that, oData;
			that = this;
			
			oData = {
				"Title": frameworkText,
				"InstantiationEnabled": (instantiationEnabled ? 1 : 0),
				"Usercreatable": (userCreatable ? 1 : 0),
				"Isproject": (isProject ? 1 : 0),
				"Sortf": sortf,
				"FaGroupId": faGroupId
			};

			this.getView().setBusy(true);
			
			this.getRootModel().update("/MASTER_ELEMENTSSet(" + this.sObjectId + ")", oData, {
				success: function(data, response) {
					that.getView().setBusy(false);
					that.showMessageToast("Updated Framework Title");
				},
				error: function(oError) {
					that.getView().setBusy(false);
					that.showErrorBox("Save Failed");
				}
			});
			this.onCloseEditDialog();

		},
		
		onEditFrameworkPress: function()
		{
			if (!this.editFrameworkDialog) {
				this.editFrameworkDialog = sap.ui.xmlfragment("zui5_fwdef.view.dialogs.EditFramework", this);

				//to get access to the global model
				this.getView().addDependent(this.editFrameworkDialog);
			}

			this.editFrameworkDialog.open();
		},
		
		onCloseEditDialog: function()
		{
			this.editFrameworkDialog.close();
		},
		
		_openPeriodPopup: function()
		{
			if (!this.createPeriodDialog) {
				this.createPeriodDialog = sap.ui.xmlfragment("zui5_fwdef.view.dialogs.CreatePeriod", this);

				//to get access to the global model
				this.getView().addDependent(this.createPeriodDialog);
			}

			this.createPeriodDialog.open();
		},

		onClickCreate: function() {
			this._resetPeriodForm();
			
			this._openPeriodPopup();
		},

		onSubmitCreatePeriod: function() {
			var that, oParameters, oDataModel, framework, periodForm;
			that = this;

			framework = this.getView().getBindingContext().getObject();
			periodForm = this.getModel("detailView").getProperty("/periodForm");
			
			oParameters = {
				"Text": periodForm.Text,
				"Status": periodForm.Status,
				"Startdate": periodForm.StartDate,
				"Enddate": periodForm.Enddate,
				'MasterElementId': framework.Id
			};

			this.getRootModel().create('/PERIODSSet', oParameters, {
				success: function(result) {
					that.showMessageToast("Period added");
					that.createPeriodDialog.close();
					that._loadPeriods();
				},
				error: function() {
					that.createPeriodDialog.close();
					that.showErrorBox("Could not create period");
				}
			});
		},

		onCloseCreateDialog: function() {
			this._resetPeriodForm();
			
			this.createPeriodDialog.close();
		},


		onClickDeletePeriod: function() {
			var dialog;
			var that = this;

			var period = this._getSelectedPeriod();

			dialog = this.confirmDialog("Are you sure you want to delete this period?", function() {

				var entitySet = "/PERIODSSet(" + period.Id + ")";
				that.getRootModel().remove(entitySet, {
					success: function(oData, response) {
						that.showMessageToast("Period deleted");
						that._loadPeriods();
						dialog.close();
					},
					error: function(oError) {
						that.showErrorBox("Deletion Failed");
						dialog.close();
					}
				});
			});
		},

		onSubmitEditPeriod: function() {
		
			var form = this.getModel("detailView").getProperty("/periodForm");
			var that = this, oData;
			
			oData = {
				"Startdate": form.Startdate,
				"Enddate": form.Enddate,
				"Text": form.Text,
				"Status": form.Status
			};

			this.getView().setBusy(true);
			
			this.getRootModel().update("/PERIODSSet(" + form.Id + ")", oData, {
				success: function(oData, response) {
					that.getView().setBusy(false);
					that.showMessageToast("Updated Period");
					that._loadPeriods();
				},
				error: function(oError) {
					that.getView().setBusy(false);
					that.showErrorBox("Save Failed");
				}
			});
			that.createPeriodDialog.close();
			
		},
		
		onClickEdit: function() {
			var selectedPeriod = this._getSelectedPeriod();
			
			selectedPeriod.Startdate = this.toUTCDate(selectedPeriod.Startdate);
			selectedPeriod.Enddate = this.toUTCDate(selectedPeriod.Enddate);
			
			this.getModel('detailView').setProperty("/periodForm", selectedPeriod);
			
			this._openPeriodPopup();
		},

		onPeriodSelection: function(oEvent) {
			var oViewModel = this.getModel("detailView");
			var oSelectedPeriod = oEvent.getParameter("rowContext").getObject();
			
			oViewModel.setProperty("/selectedPeriod", oSelectedPeriod);
		},

		_resetSelection: function() {
			var oViewModel = this.getModel("detailView");
			oViewModel.setProperty("/selectedPeriod", {});

			this.byId("periodSelect").clearSelection();
		},

		/* =========================================================== */
		/* begin: internal methods                                     */
		/* =========================================================== */

		/**
		 * Binds the view to the object path and expands the aggregated line items.
		 * @function
		 * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
		 * @private
		 */
		_onObjectMatched: function(oEvent) {
			this.sObjectId = oEvent.getParameter("arguments").objectId;
			this.getModel().metadataLoaded().then(function() {
				var sObjectPath = this.getModel().createKey("MASTER_ELEMENTSSet", {
					Id: this.sObjectId
				});
				this._bindView("/" + sObjectPath);
			}.bind(this));
		},

		/**
		 * Binds the view to the object path. Makes sure that detail view displays
		 * a busy indicator while data for the corresponding element binding is loaded.
		 * @function
		 * @param {string} sObjectPath path to the object to be bound to the view.
		 * @private
		 */
		_bindView: function(sObjectPath) {
			// Set busy indicator during view binding
			var that = this;
			var oViewModel = this.getModel("detailView");

			// If the view was not bound yet its not busy, only if the binding requests data it is set to busy again
			oViewModel.setProperty("/busy", false);

			this.getView().bindElement({
				path: sObjectPath,
				events: {
					change: this._onBindingChange.bind(this),
					dataRequested: function() {
						oViewModel.setProperty("/busy", true);
					},
					dataReceived: function() {
						oViewModel.setProperty("/busy", false);

					}
				}
			});

		},

		_loadPeriods: function() {
			var oViewModel = this.getModel("detailView");
			var oDataModel = this.getRootModel();

			var framework = this.getView().getBindingContext().getObject();

			var aFilters = [new sap.ui.model.Filter("MasterElementId", sap.ui.model.FilterOperator.EQ, framework.Id)];

			oDataModel.read("/PERIODSSet", {
				filters: aFilters,
				success: function(oData, oResponse) {
					oViewModel.setProperty("/periods", oData.results);
				}
			});
		},

		_onBindingChange: function() {
			var oView = this.getView(),
				oElementBinding = oView.getElementBinding();

			// No data for the binding
			if (!oElementBinding.getBoundContext()) {
				this.getRouter().getTargets().display("detailObjectNotFound");
				// if object could not be found, the selection in the master list
				// does not make sense anymore.
				this.getOwnerComponent().oListSelector.clearMasterListSelection();
				return;
			}

			var sPath = oElementBinding.getPath();

			this.getOwnerComponent().oListSelector.selectAListItem(sPath);

			this._loadPeriods();
			this._resetSelection();
		},
		
		_resetPeriodForm: function()
		{
			this.getModel("detailView").setProperty("/periodForm", {
				Text: null,
				//Status: "",
				Id: null
			});
		},

		_getSelectedPeriod: function() {
			return this.getModel("detailView").getProperty("/selectedPeriod");
		},

		_onMetadataLoaded: function() {
			// Store original busy indicator delay for the detail view
			var iOriginalViewBusyDelay = this.getView().getBusyIndicatorDelay(),
				oViewModel = this.getModel("detailView");

			// Make sure busy indicator is displayed immediately when
			// detail view is displayed for the first time
			oViewModel.setProperty("/delay", 0);

			// Binding the view will set it to not busy - so the view is always busy if it is not bound
			oViewModel.setProperty("/busy", true);
			// Restore original busy indicator delay for the detail view
			oViewModel.setProperty("/delay", iOriginalViewBusyDelay);
		}

	});

});