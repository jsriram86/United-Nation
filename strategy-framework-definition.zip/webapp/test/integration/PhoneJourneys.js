jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
	"sap/ui/test/Opa5",
	"zui5_fwdef/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"zui5_fwdef/test/integration/pages/App",
	"zui5_fwdef/test/integration/pages/Browser",
	"zui5_fwdef/test/integration/pages/Master",
	"zui5_fwdef/test/integration/pages/Detail",
	"zui5_fwdef/test/integration/pages/NotFound"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "zui5_fwdef.view."
	});

	sap.ui.require([
		"zui5_fwdef/test/integration/NavigationJourneyPhone",
		"zui5_fwdef/test/integration/NotFoundJourneyPhone",
		"zui5_fwdef/test/integration/BusyJourneyPhone"
	], function () {
		QUnit.start();
	});
});